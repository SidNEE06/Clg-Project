# FrameHire 🚀

A freelance marketplace platform — connecting clients with skilled freelancers.

## Project Structure

```
FrameHire/
├── backend/          # FastAPI backend (Python)
├── frontend/         # Frontend (HTML, CSS, JS, React)
└── README.md
```

## Backend

**Tech Stack:** FastAPI · SQLAlchemy · Pydantic · JWT Auth

### Setup

```bash
cd backend
uv sync           # Install dependencies
uv run uvicorn app.main:app --reload --port 8000
```

### API Docs

Once running, visit: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

## Frontend

### Setup

```bash
cd frontend
npm install
npm start         # Runs on http://127.0.0.1:3000
```
