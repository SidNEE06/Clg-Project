document.addEventListener('DOMContentLoaded', () => {
    console.log("FramHire Scripts Loaded");

    const searchBtn = document.querySelector('.search-icon-btn');
    const searchInput = document.querySelector('.search-bar');

    if (searchBtn && searchInput) {
        searchBtn.addEventListener('click', () => {
            const query = searchInput.value.trim();
            if (query) {
                alert(`Searching for: ${query}`);
            } else {
                searchInput.focus();
                searchInput.style.border = "2px solid #1dbf73";
                setTimeout(() => {
                    searchInput.style.border = "none";
                }, 2000);
            }
        });

        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                searchBtn.click();
            }
        });
    }

    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.style.background = '#404145';
        } else {
            header.style.background = 'transparent';
        }
    });
});
