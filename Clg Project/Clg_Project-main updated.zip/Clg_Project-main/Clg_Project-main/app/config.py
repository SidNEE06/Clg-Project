from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

db_url = "postgresql://postgres:8237@localhost:5432/framehire_db"
engine = create_engine(db_url)


SessionLocal = sessionmaker(autoflush=False, autocommit = False, bind=engine)