# for i in range(5):
#     sum = 0
#     for j in range(3):
#         j = int(input(f"Enter Marks of Student {i+1} of subject {j+1}"))
#         sum = sum +j
#     avg = sum/3

#     if avg >90:
#         grade = "A"
#     elif avg > 80 and avg <= 90:
#         grade = "B"
#     elif avg >70 and avg <=80:
#         grade = "C"
#     elif avg > 60 and avg <=70:
#         grade = "D"
#     else:
#         grade = "F"

#     if grade == "A" or grade == "B" or grade == "C":
#         print(f"Following are the students who have scored above average marks :")
#         print(f"Student {i+1} : Average Marks = {avg}")


    

result = ""   # store output here

for i in range(5):
    total = 0
    for j in range(3):
        marks = int(input(f"Enter Marks of Student {i+1} of subject {j+1}: "))
        total += marks

    avg = total / 3

    if avg > 90:
        grade = "A"
    elif avg > 80:
        grade = "B"
    elif avg > 70:
        grade = "C"
    elif avg > 60:
        grade = "D"
    else:
        grade = "F"

    if grade in ("A", "B", "C"):
        result += f"Student {i+1} : Average Marks = {avg}\n"

print("Following are the students who have scored above average marks:")
print(result)
