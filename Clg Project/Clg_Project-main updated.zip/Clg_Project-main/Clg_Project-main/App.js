const { useState, useEffect } = React;

function PopularServices() {
    const services = [
        { title: "AI Artists", color: "#ff7640" },
        { title: "Logo Design", color: "#ffb224" },
        { title: "WordPress", color: "#1dbf73" },
        { title: "Voice Over", color: "#404145" },
        { title: "Video Explainer", color: "#7a4dff" }
    ];

    return (
        <div className="popular-service-slider">
            {services.map((service, index) => (
                <div key={index} className="pop-card" style={{ borderTop: `4px solid ${service.color}` }}>
                    <h3>{service.title}</h3>
                </div>
            ))}
        </div>
    );
}

function App() {
    return (
        <div>
            <PopularServices />
        </div>
    );
}

const rootElement = document.getElementById('react-root');
const root = ReactDOM.createRoot(rootElement);
root.render(<App />);
