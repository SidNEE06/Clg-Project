/* ═══════════════════════════════════════════════════
   FrameHire — profile.js
   Profile page logic — auth guard, user data, role selection
   ═══════════════════════════════════════════════════ */

const BACKEND = 'http://127.0.0.1:8000';

(function profileInit() {
    const token = localStorage.getItem('token');

    // ── Auth guard: no token → redirect to homepage ──
    if (!token) {
        window.location.href = 'Mainpage.html';
        return;
    }

    // ── Fetch user profile from /auth/me ──
    fetchProfile(token);

    // ── Restore saved role ──
    const savedRole = localStorage.getItem('userRole');
    if (savedRole) {
        highlightRole(savedRole);
        updateRoleInfo(savedRole);
    }

    // ── Restore saved email for display if /auth/me is slow ──
    const savedEmail = localStorage.getItem('userEmail');
    if (savedEmail) {
        setProfileEmail(savedEmail);
    }
})();

async function fetchProfile(token) {
    try {
        const res = await fetch(`${BACKEND}/auth/me`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!res.ok) {
            // Token expired or invalid
            if (res.status === 401) {
                localStorage.removeItem('token');
                localStorage.removeItem('userEmail');
                window.location.href = 'Mainpage.html';
                return;
            }
            throw new Error('Failed to fetch profile');
        }

        const data = await res.json();

        // Backend's get_current_user returns { "email": user_id }
        // We also store the actual email from login in localStorage
        const email = localStorage.getItem('userEmail') || data.email || 'User';
        setProfileEmail(email);

    } catch (err) {
        console.error('Profile fetch error:', err);
        // Fall back to stored email
        const email = localStorage.getItem('userEmail') || 'User';
        setProfileEmail(email);
    }
}

function setProfileEmail(email) {
    const el = document.getElementById('profile-email');
    const heading = document.getElementById('welcome-heading');
    if (el) el.textContent = email;
    if (heading) heading.textContent = `Welcome back!`;
}

// ── Role Selection ──
function selectRole(role) {
    localStorage.setItem('userRole', role);
    highlightRole(role);
    updateRoleInfo(role);
}

function highlightRole(role) {
    const hireCard = document.getElementById('role-hire');
    const freelanceCard = document.getElementById('role-freelance');

    hireCard.classList.remove('selected');
    freelanceCard.classList.remove('selected');

    if (role === 'hire') {
        hireCard.classList.add('selected');
    } else if (role === 'freelance') {
        freelanceCard.classList.add('selected');
    }
}

function updateRoleInfo(role) {
    const infoRole = document.getElementById('info-role');
    if (infoRole) {
        if (role === 'hire') {
            infoRole.textContent = 'Hiring';
        } else if (role === 'freelance') {
            infoRole.textContent = 'Freelancer';
        } else {
            infoRole.textContent = 'Not selected';
        }
    }
}
