/* ═══════════════════════════════════════════════════
   FrameHire — script.js
   Shared UI logic for all pages
   ═══════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {
    console.log('FrameHire Scripts Loaded');

    // ──────────── Auth-aware Navbar ────────────
    updateNavbar();

    // ──────────── Navbar scroll behaviour ────────────
    const navbar = document.getElementById('navbar');
    if (navbar && !navbar.classList.contains('scrolled')) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 60) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }

    // ──────────── Mobile hamburger ────────────
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('nav-links');

    if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('open');
        });

        navLinks.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('open');
            });
        });
    }

    // ──────────── Hero particles (only on pages with the container) ────────────
    const particleContainer = document.getElementById('hero-particles');
    if (particleContainer) {
        for (let i = 0; i < 30; i++) {
            const p = document.createElement('div');
            p.classList.add('particle');
            p.style.left = Math.random() * 100 + '%';
            p.style.animationDuration = 6 + Math.random() * 10 + 's';
            p.style.animationDelay = Math.random() * 8 + 's';
            p.style.width = p.style.height = 2 + Math.random() * 4 + 'px';
            particleContainer.appendChild(p);
        }
    }

    // ──────────── Scroll reveal ────────────
    const revealEls = document.querySelectorAll(
        '.feature-card, .step-card, .cta-inner, .footer-col, .role-card, .info-card, .profile-header'
    );
    revealEls.forEach(el => el.classList.add('reveal'));

    const observer = new IntersectionObserver(
        entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        },
        { threshold: 0.15 }
    );
    revealEls.forEach(el => observer.observe(el));
});

// ══════════════════════════════════════════════════
//  Auth-aware Navbar
// ══════════════════════════════════════════════════
function updateNavbar() {
    const token = localStorage.getItem('token');
    const guestNav = document.getElementById('nav-auth-guest');
    const userNav = document.getElementById('nav-auth-user');

    if (!guestNav || !userNav) return;

    if (token) {
        guestNav.style.display = 'none';
        userNav.style.display = 'flex';
    } else {
        guestNav.style.display = 'flex';
        userNav.style.display = 'none';
    }
}

// ══════════════════════════════════════════════════
//  Auth Modal helpers (homepage only)
// ══════════════════════════════════════════════════
function openAuthModal(tab) {
    const overlay = document.getElementById('auth-modal-overlay');
    if (overlay) {
        overlay.classList.add('active');
        window.dispatchEvent(new CustomEvent('auth-open', { detail: tab }));
    }
}

function closeAuthModal() {
    const overlay = document.getElementById('auth-modal-overlay');
    if (overlay) overlay.classList.remove('active');
}

// Close modal when clicking overlay background
document.addEventListener('click', (e) => {
    if (e.target && e.target.id === 'auth-modal-overlay') {
        closeAuthModal();
    }
});

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAuthModal();
});

// ══════════════════════════════════════════════════
//  Logout
// ══════════════════════════════════════════════════
function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userRole');
    window.location.href = 'Mainpage.html';
}
