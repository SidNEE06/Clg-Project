/* ═══════════════════════════════════════════════════
   FrameHire — freelancer-dashboard.js
   Loads and manages the freelancer dashboard page
   ═══════════════════════════════════════════════════ */

const BACKEND = 'http://127.0.0.1:8000';

// Local projects store (in-memory for demo — extend with DB later)
let localProjects = JSON.parse(localStorage.getItem('fh_projects') || '[]');
let currentProfile = null;

(function dashInit() {
    const token = localStorage.getItem('token');

    // Auth guard
    if (!token) {
        window.location.href = 'Mainpage.html';
        return;
    }

    // Role guard
    const role = localStorage.getItem('userRole');
    if (role && role !== 'freelancer') {
        window.location.href = 'browse.html';
        return;
    }

    loadDashboard(token);
    renderProjects();
})();

async function loadDashboard(token) {
    try {
        // Load user info
        const meRes = await fetch(`${BACKEND}/auth/me`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!meRes.ok) throw new Error('Auth failed');
        const me = await meRes.json();

        const email = me.email || localStorage.getItem('userEmail') || 'Freelancer';
        document.getElementById('dash-email').textContent = email;

        // Set avatar initials
        const initials = email.charAt(0).toUpperCase();
        const avatarEl = document.getElementById('dashboard-avatar');
        if (avatarEl) avatarEl.textContent = initials;

        // Load freelancer profile
        const profRes = await fetch(`${BACKEND}/freelancers/${me.id}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (profRes.ok) {
            currentProfile = await profRes.json();
            renderProfile(currentProfile);
        } else {
            // No profile yet — prompt to set up
            document.getElementById('dash-greeting').textContent = 'Welcome! Let\'s set up your profile.';
            const setupLink = document.createElement('a');
            setupLink.href = 'freelancer-setup.html';
            setupLink.className = 'btn btn-primary';
            setupLink.style.marginTop = '1rem';
            setupLink.textContent = 'Complete Profile Setup';
            document.getElementById('profile-view').appendChild(setupLink);
        }

    } catch (err) {
        console.error('Dashboard load error:', err);
        // Fallback to stored email
        const email = localStorage.getItem('userEmail') || 'Freelancer';
        document.getElementById('dash-email').textContent = email;
        const initials = email.charAt(0).toUpperCase();
        const avatarEl = document.getElementById('dashboard-avatar');
        if (avatarEl) avatarEl.textContent = initials;
    }
}

function renderProfile(profile) {
    if (!profile) return;
    currentProfile = profile;

    // Stats
    const skillList = profile.skills ? profile.skills.split(',').map(s => s.trim()).join(', ') : '—';
    document.getElementById('stat-skills').textContent = skillList;
    document.getElementById('stat-exp').textContent = profile.years_experience + ' yr' + (profile.years_experience !== 1 ? 's' : '');
    document.getElementById('stat-rate').textContent = profile.hourly_rate ? '$' + profile.hourly_rate + '/hr' : 'Not set';
    document.getElementById('stat-since').textContent = profile.created_at
        ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
        : '—';

    // Bio
    document.getElementById('view-bio').textContent = profile.bio || '—';

    // Skill tags
    const skillsContainer = document.getElementById('view-skills');
    skillsContainer.innerHTML = '';
    if (profile.skills) {
        profile.skills.split(',').forEach(skill => {
            const tag = document.createElement('span');
            tag.className = 'skill-tag';
            tag.textContent = skill.trim();
            skillsContainer.appendChild(tag);
        });
    }

    // Portfolio links
    const portContainer = document.getElementById('view-portfolio');
    portContainer.innerHTML = '';
    if (profile.portfolio_links) {
        const links = profile.portfolio_links.split(',').map(l => l.trim()).filter(Boolean);
        links.forEach(url => {
            const a = document.createElement('a');
            a.href = url.startsWith('http') ? url : 'https://' + url;
            a.target = '_blank';
            a.rel = 'noopener noreferrer';
            a.className = 'portfolio-link';
            a.textContent = url.replace(/^https?:\/\//, '').split('/')[0];
            portContainer.appendChild(a);
        });
    } else {
        portContainer.textContent = '—';
    }

    // Pricing
    document.getElementById('pricing-amount').textContent = profile.hourly_rate ? '$' + profile.hourly_rate : 'Not set';

    // Pre-fill edit fields
    document.getElementById('edit-skills').value = profile.skills || '';
    document.getElementById('edit-exp').value = profile.years_experience || 0;
    document.getElementById('edit-bio').value = profile.bio || '';
    document.getElementById('edit-portfolio').value = profile.portfolio_links || '';
    document.getElementById('edit-rate').value = profile.hourly_rate || '';
    document.getElementById('new-rate').value = profile.hourly_rate || '';
}

// ── Edit Profile ──
function toggleEditProfile() {
    const view = document.getElementById('profile-view');
    const edit = document.getElementById('profile-edit');
    const btn = document.getElementById('edit-profile-btn');
    const isEditing = edit.style.display !== 'none';
    view.style.display = isEditing ? '' : 'none';
    edit.style.display = isEditing ? 'none' : '';
    btn.textContent = isEditing ? 'Edit' : 'Cancel';
}

async function saveProfile() {
    const token = localStorage.getItem('token');
    const msgEl = document.getElementById('edit-message');

    const payload = {
        skills: document.getElementById('edit-skills').value.trim(),
        years_experience: parseInt(document.getElementById('edit-exp').value, 10) || 0,
        bio: document.getElementById('edit-bio').value.trim(),
        portfolio_links: document.getElementById('edit-portfolio').value.trim() || null,
        hourly_rate: parseFloat(document.getElementById('edit-rate').value) || null
    };

    try {
        const res = await fetch(`${BACKEND}/freelancers/profile`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Failed to save');

        renderProfile(data);
        msgEl.textContent = '✅ Profile updated!';
        msgEl.className = 'setup-message success';
        msgEl.style.display = 'block';
        setTimeout(() => {
            toggleEditProfile();
            msgEl.style.display = 'none';
        }, 1500);

    } catch (err) {
        msgEl.textContent = 'Error: ' + err.message;
        msgEl.className = 'setup-message error';
        msgEl.style.display = 'block';
    }
}

// ── Edit Pricing ──
function toggleEditRate() {
    const view = document.getElementById('pricing-view');
    const edit = document.getElementById('pricing-edit');
    const isEditing = edit.style.display !== 'none';
    view.style.display = isEditing ? '' : 'none';
    edit.style.display = isEditing ? 'none' : '';
}

async function saveRate() {
    const token = localStorage.getItem('token');
    const newRate = parseFloat(document.getElementById('new-rate').value);
    const msgEl = document.getElementById('rate-message');

    if (isNaN(newRate) || newRate <= 0) {
        msgEl.textContent = 'Please enter a valid rate.';
        msgEl.className = 'setup-message error';
        msgEl.style.display = 'block';
        return;
    }

    const payload = {
        skills: currentProfile?.skills || '',
        years_experience: currentProfile?.years_experience || 0,
        bio: currentProfile?.bio || '',
        portfolio_links: currentProfile?.portfolio_links || null,
        hourly_rate: newRate
    };

    try {
        const res = await fetch(`${BACKEND}/freelancers/profile`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Failed to update rate');

        renderProfile(data);
        msgEl.textContent = '✅ Rate updated!';
        msgEl.className = 'setup-message success';
        msgEl.style.display = 'block';
        setTimeout(() => {
            toggleEditRate();
            msgEl.style.display = 'none';
        }, 1500);

    } catch (err) {
        msgEl.textContent = 'Error: ' + err.message;
        msgEl.className = 'setup-message error';
        msgEl.style.display = 'block';
    }
}

// ── Projects (local store) ──
function addProject() {
    const title = document.getElementById('proj-title').value.trim();
    const desc = document.getElementById('proj-desc').value.trim();
    const link = document.getElementById('proj-link').value.trim();

    if (!title || !desc) {
        alert('Please fill in the project title and description.');
        return;
    }

    localProjects.push({ title, desc, link, date: new Date().toLocaleDateString() });
    localStorage.setItem('fh_projects', JSON.stringify(localProjects));

    document.getElementById('proj-title').value = '';
    document.getElementById('proj-desc').value = '';
    document.getElementById('proj-link').value = '';

    renderProjects();
}

function deleteProject(index) {
    localProjects.splice(index, 1);
    localStorage.setItem('fh_projects', JSON.stringify(localProjects));
    renderProjects();
}

function renderProjects() {
    const container = document.getElementById('projects-list');
    if (!container) return;

    if (localProjects.length === 0) {
        container.innerHTML = '<p class="empty-state">No projects added yet. Add your first one below!</p>';
        return;
    }

    container.innerHTML = localProjects.map((p, i) => `
        <div class="project-item" id="project-${i}">
            <div class="project-item-header">
                <h4>${escHtml(p.title)}</h4>
                <button class="btn-delete" onclick="deleteProject(${i})" aria-label="Delete project">✕</button>
            </div>
            <p class="project-desc">${escHtml(p.desc)}</p>
            ${p.link ? `<a href="${escHtml(p.link)}" target="_blank" rel="noopener noreferrer" class="portfolio-link">View Project →</a>` : ''}
            <span class="project-date">Added ${p.date}</span>
        </div>
    `).join('');
}

function escHtml(text) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(text));
    return div.innerHTML;
}
