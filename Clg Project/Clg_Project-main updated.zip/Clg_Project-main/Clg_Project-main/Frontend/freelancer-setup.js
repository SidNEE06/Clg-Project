/* ═══════════════════════════════════════════════════
   FrameHire — freelancer-setup.js
   Handles freelancer profile setup form submission
   ═══════════════════════════════════════════════════ */

const BACKEND = 'http://127.0.0.1:8000';

(function setupInit() {
    const token = localStorage.getItem('token');

    // Auth guard
    if (!token) {
        window.location.href = 'Mainpage.html';
        return;
    }

    // Role guard — only freelancers should be here
    const role = localStorage.getItem('userRole');
    if (role && role !== 'freelancer') {
        window.location.href = 'browse.html';
        return;
    }

    // Wire up form
    const form = document.getElementById('setup-form');
    if (form) {
        form.addEventListener('submit', handleSetup);
    }
})();

async function handleSetup(e) {
    e.preventDefault();

    const token = localStorage.getItem('token');
    const btn = document.getElementById('setup-submit-btn');
    const msgEl = document.getElementById('setup-message');

    const skills = document.getElementById('skills').value.trim();
    const years_experience = parseInt(document.getElementById('years_experience').value, 10);
    const bio = document.getElementById('bio').value.trim();
    const portfolio_links = document.getElementById('portfolio_links').value.trim() || null;
    const hourly_rate_raw = document.getElementById('hourly_rate').value;
    const hourly_rate = hourly_rate_raw ? parseFloat(hourly_rate_raw) : null;

    if (!skills || !bio || isNaN(years_experience)) {
        showMessage('Please fill in all required fields.', 'error');
        return;
    }

    btn.disabled = true;
    btn.textContent = 'Saving…';

    try {
        const res = await fetch(`${BACKEND}/freelancers/profile`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ skills, years_experience, bio, portfolio_links, hourly_rate })
        });

        const data = await res.json();

        if (!res.ok) {
            throw new Error(data.detail || JSON.stringify(data));
        }

        showMessage('Profile saved! Redirecting to your dashboard…', 'success');

        setTimeout(() => {
            window.location.href = 'freelancer-dashboard.html';
        }, 1000);

    } catch (err) {
        showMessage('Error: ' + err.message, 'error');
        btn.disabled = false;
        btn.innerHTML = 'Save Profile &amp; Go to Dashboard <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>';
    }
}

function showMessage(text, type) {
    const el = document.getElementById('setup-message');
    if (!el) return;
    el.textContent = text;
    el.className = `setup-message ${type}`;
    el.style.display = 'block';
}
