/* ═══════════════════════════════════════════════════
   FrameHire — App.js  (React 18, loaded via Babel CDN)
   Auth tabs rendered inside the modal on Mainpage.
   Role-based registration + login redirect logic.
   ═══════════════════════════════════════════════════ */

const { useState, useEffect } = React;

function AuthTabs() {
    const [tab, setTab] = useState('login');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('customer');
    const [message, setMessage] = useState('');
    const [msgType, setMsgType] = useState(''); // 'success' | 'error'
    const [loading, setLoading] = useState(false);

    const backend = 'http://127.0.0.1:8000';

    // Listen for external tab-switch events from vanilla JS buttons
    useEffect(() => {
        function onAuthOpen(e) {
            const requested = e.detail; // 'login' | 'register'
            if (requested) setTab(requested);
            setMessage('');
        }
        window.addEventListener('auth-open', onAuthOpen);
        return () => window.removeEventListener('auth-open', onAuthOpen);
    }, []);

    // ── Redirect helper based on role ──
    function redirectByRole(userRole) {
        if (userRole === 'freelancer') {
            window.location.href = 'freelancer-setup.html';
        } else {
            window.location.href = 'browse.html';
        }
    }

    // ── Register ──
    async function handleRegister(e) {
        e.preventDefault();
        setMessage('');
        setLoading(true);
        try {
            const res = await fetch(`${backend}/auth/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password, role })
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || JSON.stringify(data));

            setMessage('Registered successfully! Logging you in…');
            setMsgType('success');

            // Auto-login after successful registration
            await autoLogin(email, password, role);

        } catch (err) {
            setMessage('Register error: ' + err.message);
            setMsgType('error');
            setLoading(false);
        }
    }

    // ── Login ──
    async function handleLogin(e) {
        e.preventDefault();
        setMessage('');
        setLoading(true);
        try {
            const body = new URLSearchParams();
            body.append('username', email);
            body.append('password', password);

            const res = await fetch(`${backend}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString()
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || JSON.stringify(data));

            // Store token and email
            localStorage.setItem('token', data.access_token);
            localStorage.setItem('userEmail', email);

            setMessage('Login successful! Redirecting…');
            setMsgType('success');

            // Fetch role from /auth/me then redirect
            try {
                const meRes = await fetch(`${backend}/auth/me`, {
                    headers: { 'Authorization': `Bearer ${data.access_token}` }
                });
                const meData = await meRes.json();
                const userRole = meData.role || 'customer';
                localStorage.setItem('userRole', userRole);
                setTimeout(() => redirectByRole(userRole), 600);
            } catch {
                // Fallback
                setTimeout(() => { window.location.href = 'browse.html'; }, 600);
            }

        } catch (err) {
            setMessage('Login error: ' + err.message);
            setMsgType('error');
            setLoading(false);
        }
    }

    // ── Auto-login helper (called after register) ──
    async function autoLogin(userEmail, userPassword, userRole) {
        try {
            const body = new URLSearchParams();
            body.append('username', userEmail);
            body.append('password', userPassword);

            const res = await fetch(`${backend}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString()
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || JSON.stringify(data));

            localStorage.setItem('token', data.access_token);
            localStorage.setItem('userEmail', userEmail);
            localStorage.setItem('userRole', userRole);

            setMessage('Logged in! Redirecting…');
            setMsgType('success');

            setTimeout(() => redirectByRole(userRole), 600);

        } catch (err) {
            // Auto-login failed — show manual login message
            setMessage('Registered! Please log in manually.');
            setMsgType('success');
            setTab('login');
            setLoading(false);
        }
    }

    return (
        <div className="auth-container">
            <h2 className="auth-title">
                {tab === 'login' ? 'Welcome Back' : 'Create Account'}
            </h2>
            <p className="auth-subtitle">
                {tab === 'login'
                    ? 'Sign in to access your dashboard.'
                    : 'Join FrameHire and start today.'}
            </p>

            <div className="tabs">
                <button
                    className={tab === 'login' ? 'active' : ''}
                    onClick={() => { setTab('login'); setMessage(''); }}
                    disabled={loading}
                >
                    Login
                </button>
                <button
                    className={tab === 'register' ? 'active' : ''}
                    onClick={() => { setTab('register'); setMessage(''); }}
                    disabled={loading}
                >
                    Register
                </button>
            </div>

            {tab === 'login' ? (
                <form onSubmit={handleLogin} className="auth-form">
                    <input
                        placeholder="Email address"
                        type="email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        required
                        disabled={loading}
                    />
                    <input
                        placeholder="Password"
                        type="password"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        required
                        disabled={loading}
                    />
                    <button type="submit" disabled={loading}>
                        {loading ? 'Signing in…' : 'Login'}
                    </button>
                </form>
            ) : (
                <form onSubmit={handleRegister} className="auth-form">
                    <input
                        placeholder="Email address"
                        type="email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        required
                        disabled={loading}
                    />
                    <input
                        placeholder="Password"
                        type="password"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        required
                        disabled={loading}
                    />

                    {/* ── Role Picker ── */}
                    <p className="role-picker-label">I want to join as:</p>
                    <div className="role-picker">
                        <div
                            id="role-customer"
                            className={`role-pick-card ${role === 'customer' ? 'active' : ''}`}
                            onClick={() => !loading && setRole('customer')}
                        >
                            <span className="role-pick-icon">🧑‍💼</span>
                            <span className="role-pick-title">Customer</span>
                            <span className="role-pick-desc">Hire freelancers</span>
                        </div>
                        <div
                            id="role-freelancer"
                            className={`role-pick-card ${role === 'freelancer' ? 'active' : ''}`}
                            onClick={() => !loading && setRole('freelancer')}
                        >
                            <span className="role-pick-icon">👨‍🎨</span>
                            <span className="role-pick-title">Freelancer</span>
                            <span className="role-pick-desc">Offer services</span>
                        </div>
                    </div>

                    <button type="submit" disabled={loading}>
                        {loading ? 'Creating account…' : 'Register'}
                    </button>
                </form>
            )}

            {message && (
                <div className={`auth-message ${msgType}`}>{message}</div>
            )}
        </div>
    );
}

/* ──── Mount ──── */
function App() {
    return <AuthTabs />;
}

const rootElement = document.getElementById('react-root');
const root = ReactDOM.createRoot(rootElement);
root.render(<App />);
