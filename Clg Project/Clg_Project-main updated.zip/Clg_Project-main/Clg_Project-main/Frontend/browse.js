/* ═══════════════════════════════════════════════════
   FrameHire — browse.js
   Browse freelancers page — load & render freelancer cards
   ═══════════════════════════════════════════════════ */

const BACKEND = 'http://127.0.0.1:8000';
let allFreelancers = [];

(function browseInit() {
    const token = localStorage.getItem('token');

    // Auth guard
    if (!token) {
        window.location.href = 'Mainpage.html';
        return;
    }

    loadFreelancers();
})();

async function loadFreelancers() {
    const loadingEl = document.getElementById('browse-loading');
    const emptyEl = document.getElementById('browse-empty');
    const gridEl = document.getElementById('freelancer-grid');

    try {
        const res = await fetch(`${BACKEND}/freelancers/`);
        if (!res.ok) throw new Error('Failed to load freelancers');

        allFreelancers = await res.json();

        loadingEl.style.display = 'none';

        if (allFreelancers.length === 0) {
            emptyEl.style.display = 'flex';
            return;
        }

        gridEl.style.display = 'grid';
        renderGrid(allFreelancers);

    } catch (err) {
        console.error('Browse error:', err);
        loadingEl.style.display = 'none';
        emptyEl.style.display = 'flex';
        emptyEl.querySelector('p').textContent = 'Unable to load freelancers. Please try again.';
    }
}

function renderGrid(freelancers) {
    const gridEl = document.getElementById('freelancer-grid');
    if (!gridEl) return;

    gridEl.innerHTML = freelancers.map(f => {
        const email = f.email || 'Freelancer';
        const name = email.split('@')[0]
            .replace(/[._-]/g, ' ')
            .replace(/\b\w/g, c => c.toUpperCase());
        const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

        const skills = f.skills
            ? f.skills.split(',').map(s => s.trim()).slice(0, 4)
            : [];
        const bio = f.bio || 'No bio provided.';
        const rate = f.hourly_rate ? '$' + f.hourly_rate + '/hr' : 'Rate not set';
        const exp = f.years_experience !== undefined ? f.years_experience + ' yr' + (f.years_experience !== 1 ? 's' : '') : '—';

        return `
            <div class="freelancer-card reveal" data-skills="${escHtml(f.skills || '')}" data-name="${escHtml(name)}">
                <div class="fc-top">
                    <div class="fc-avatar">${initials}</div>
                    <div class="fc-meta">
                        <h3 class="fc-name">${escHtml(name)}</h3>
                        <span class="fc-rate">${escHtml(rate)}</span>
                    </div>
                </div>
                <div class="fc-exp">⏱ ${escHtml(exp)} experience</div>
                <p class="fc-bio">${escHtml(bio.length > 120 ? bio.slice(0, 117) + '…' : bio)}</p>
                <div class="fc-skills">
                    ${skills.map(s => `<span class="skill-tag">${escHtml(s)}</span>`).join('')}
                    ${f.skills && f.skills.split(',').length > 4 ? `<span class="skill-tag muted">+${f.skills.split(',').length - 4} more</span>` : ''}
                </div>
                <a href="freelancer-profile.html?id=${escHtml(String(f.user_id))}" class="btn btn-primary fc-btn">View Profile</a>
            </div>
        `;
    }).join('');

    // Trigger scroll-reveal for new cards
    const cards = gridEl.querySelectorAll('.reveal');
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) entry.target.classList.add('visible');
        });
    }, { threshold: 0.1 });
    cards.forEach(card => observer.observe(card));
}

function filterCards() {
    const query = document.getElementById('search-input').value.trim().toLowerCase();
    const emptyEl = document.getElementById('browse-empty');
    const gridEl = document.getElementById('freelancer-grid');

    const filtered = query
        ? allFreelancers.filter(f =>
            (f.skills || '').toLowerCase().includes(query) ||
            (f.bio || '').toLowerCase().includes(query) ||
            (f.email || '').toLowerCase().includes(query)
        )
        : allFreelancers;

    if (filtered.length === 0) {
        gridEl.style.display = 'none';
        emptyEl.style.display = 'flex';
        emptyEl.querySelector('h3').textContent = 'No results found';
        emptyEl.querySelector('p').textContent = `No freelancers match "${query}". Try a different skill.`;
    } else {
        emptyEl.style.display = 'none';
        gridEl.style.display = 'grid';
        renderGrid(filtered);
    }
}

function escHtml(text) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(String(text)));
    return div.innerHTML;
}
