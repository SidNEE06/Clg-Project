from pydantic import BaseModel
from typing import Optional
from uuid import UUID
from datetime import datetime


class FreelancerProfileCreate(BaseModel):
    skills: str
    years_experience: int
    bio: str
    portfolio_links: Optional[str] = None
    hourly_rate: Optional[float] = None


class FreelancerProfileResponse(BaseModel):
    id: UUID
    user_id: UUID
    skills: str
    years_experience: int
    bio: str
    portfolio_links: Optional[str] = None
    hourly_rate: Optional[float] = None
    created_at: datetime
    email: Optional[str] = None  # populated from User join

    class Config:
        from_attributes = True
