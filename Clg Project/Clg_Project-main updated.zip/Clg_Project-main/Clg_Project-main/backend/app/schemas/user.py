from pydantic import BaseModel, EmailStr
from datetime import datetime
from uuid import UUID

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    role: str = "customer"  # 'freelancer' or 'customer'

class UserLogin(BaseModel):
    email : EmailStr
    password : str

class UserResponse(BaseModel):
    id: UUID
    email: EmailStr
    is_active: bool
    created_at: datetime
    role: str = "customer"

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token : str
    token_type : str