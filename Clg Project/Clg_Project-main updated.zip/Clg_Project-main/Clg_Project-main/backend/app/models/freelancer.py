from sqlalchemy import Column, String, Integer, Float, ForeignKey, Text, DateTime
from sqlalchemy.orm import relationship
import uuid
from sqlalchemy.dialects.postgresql import UUID
from app.db.database import Base
from sqlalchemy.sql import func


class FreelancerProfile(Base):
    __tablename__ = "freelancer_profiles"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("Users.id"), unique=True, nullable=False)
    skills = Column(Text, nullable=False)
    years_experience = Column(Integer, nullable=False, default=0)
    bio = Column(Text, nullable=False)
    portfolio_links = Column(Text, nullable=True)
    hourly_rate = Column(Float, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="freelancer_profile")
