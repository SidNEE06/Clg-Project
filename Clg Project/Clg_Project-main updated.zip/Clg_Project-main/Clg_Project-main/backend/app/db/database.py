from sqlalchemy import create_engine

# from sqlalchemy.dialects.postgresql import UUID

from sqlalchemy.orm import DeclarativeBase, relationship, sessionmaker

DB_URL = "postgresql://postgres:8237@localhost:5432/framehire_db"
engine = create_engine(DB_URL)

SessionLocal = sessionmaker(autoflush=False, autocommit = False, bind=engine)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


