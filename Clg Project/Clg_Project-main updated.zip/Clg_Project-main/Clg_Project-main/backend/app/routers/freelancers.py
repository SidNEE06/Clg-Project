from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from typing import List

from app.db.database import get_db
from app.models.user import User
from app.models.freelancer import FreelancerProfile
from app.schemas.freelancer import FreelancerProfileCreate, FreelancerProfileResponse
from app.core.jwt_logic_code import verify_access_token

router = APIRouter(prefix="/freelancers", tags=["Freelancers"])

oauth2_bearer = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_current_user_from_token(token: str = Depends(oauth2_bearer), db: Session = Depends(get_db)):
    payload = verify_access_token(token)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Token")
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
    return user


@router.post("/profile", response_model=FreelancerProfileResponse)
def create_or_update_profile(
    profile_data: FreelancerProfileCreate,
    current_user: User = Depends(get_current_user_from_token),
    db: Session = Depends(get_db)
):
    if current_user.role != "freelancer":
        raise HTTPException(status_code=403, detail="Only freelancers can create a profile")

    # Check if profile already exists — update it
    existing = db.query(FreelancerProfile).filter(
        FreelancerProfile.user_id == current_user.id
    ).first()

    if existing:
        existing.skills = profile_data.skills
        existing.years_experience = profile_data.years_experience
        existing.bio = profile_data.bio
        existing.portfolio_links = profile_data.portfolio_links
        existing.hourly_rate = profile_data.hourly_rate
        db.commit()
        db.refresh(existing)
        profile = existing
    else:
        profile = FreelancerProfile(
            user_id=current_user.id,
            skills=profile_data.skills,
            years_experience=profile_data.years_experience,
            bio=profile_data.bio,
            portfolio_links=profile_data.portfolio_links,
            hourly_rate=profile_data.hourly_rate
        )
        db.add(profile)
        db.commit()
        db.refresh(profile)

    # Return with email
    result = FreelancerProfileResponse.model_validate(profile)
    result.email = current_user.email
    return result


@router.get("/", response_model=List[FreelancerProfileResponse])
def list_freelancers(db: Session = Depends(get_db)):
    profiles = db.query(FreelancerProfile).all()
    results = []
    for p in profiles:
        resp = FreelancerProfileResponse.model_validate(p)
        if p.user:
            resp.email = p.user.email
        results.append(resp)
    return results


@router.get("/{user_id}", response_model=FreelancerProfileResponse)
def get_freelancer(user_id: str, db: Session = Depends(get_db)):
    profile = db.query(FreelancerProfile).filter(
        FreelancerProfile.user_id == user_id
    ).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Freelancer profile not found")
    resp = FreelancerProfileResponse.model_validate(profile)
    if profile.user:
        resp.email = profile.user.email
    return resp
