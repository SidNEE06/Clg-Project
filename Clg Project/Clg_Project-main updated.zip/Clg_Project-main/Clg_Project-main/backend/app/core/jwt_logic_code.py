from datetime import datetime, timedelta
from jose import jwt, JWTError
from typing import Annotated
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

SECRET_KEY = "c8f9a6e2d1b74e3a9c2f1d8b6e7a4c9f5d3b2a1e6c8f9a7d4b1e2c3f6a9d8b7"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
oauth2_bearer = OAuth2PasswordBearer(tokenUrl="/auth/login")

def create_access_token(data : dict) -> str:
    to_encode = data.copy()

    expire = datetime.utcnow() + timedelta(minutes = ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp" : expire})

    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_access_token(token:str):
    try:
        payload = jwt.decode(token=token, key=SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None
    
def get_current_user(token : Annotated[str, Depends(oauth2_bearer)]):
    try :
        payload = jwt.decode(token=token, key=SECRET_KEY, algorithms=[ALGORITHM] )
        user_email : str = payload.get("sub")

        if user_email is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Token")
        return {"email" : user_email }
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Token")
    


    
    