from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import auth
from app.routers import freelancers
from app.db.database import engine, Base
from app.models import user       # Ensure User model is loaded
from app.models import freelancer  # Ensure FreelancerProfile model is loaded

# Create tables (auto-creates any new tables including freelancer_profiles)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="FrameHire API",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # change later to frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(freelancers.router)

@app.get("/")
def root():
    return {"message": "FrameHire backend running"}